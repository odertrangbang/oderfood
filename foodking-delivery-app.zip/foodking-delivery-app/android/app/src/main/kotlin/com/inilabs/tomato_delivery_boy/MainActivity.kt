package com.inilabs.foodking.delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
