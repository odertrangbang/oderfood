package com.inilabs.foodking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
